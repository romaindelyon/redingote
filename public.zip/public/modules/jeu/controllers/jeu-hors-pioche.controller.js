'use strict';

angular.module('jeu').controller('JeuHorsPiocheController', ['$scope',
	function($scope) {

}]);