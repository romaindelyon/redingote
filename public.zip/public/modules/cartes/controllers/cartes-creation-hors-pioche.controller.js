'use strict';

angular.module('cartes').controller('CartesCreationHorsPiocheController', ['$scope',
	function($scope) {
		$scope.reductions = ['Aucune','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi','Dimanche'];
}]);