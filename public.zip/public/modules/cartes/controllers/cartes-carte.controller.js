'use strict';

angular.module('cartes').controller('CartesCarteController', ['$scope',
	function($scope) {
}]);