'use strict';

// Use application configuration module to register a new module
ApplicationConfiguration.registerModule('cartes');
