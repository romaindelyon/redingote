This file will no longer be updated. Use the Releases feature of the `ng-idle` repository to see a change log.
